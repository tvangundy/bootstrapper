# bootstrapper
POC repository for the windsor bootstrapper
